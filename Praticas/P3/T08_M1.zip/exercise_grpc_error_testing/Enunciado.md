# Enunciado

Introduza um novo procedimento remoto:
 - subsidize(int threshold, int amount) -> adiciona a todas as contas um amount com saldo inferior a threshold.
 - Erros resultam de nenhuma conta ter saldo baixo o suficiente para usufruir.
