# Avaliação 

### Banking 

Introduza um novo procedimento remoto withdrawal(String client, int amount):
 - decrementa amount a conta do cliente
 - chamada com keyword withdrawal
 
### Errors a tratar

 - cliente não existente
 - amount a remover superior ao balance